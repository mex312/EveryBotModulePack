from setuptools import setup

setup(
    name='EveryBotModulePack',
    version='0.1b3',
    packages=['EveryBot'],
    url='',
    license='',
    author='mex312',
    author_email='mex3122020@gmail.com',
    description='Pack for creating modules for EveryBot',
    requires=['pyTelegramBotApi'],
    install_requires=['pyTelegramBotApi']
)
