from EveryBot import Module
from EveryBot import Core
