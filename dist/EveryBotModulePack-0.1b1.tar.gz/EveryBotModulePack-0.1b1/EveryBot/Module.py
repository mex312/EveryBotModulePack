class Module:
    name = "NAMELESS"
    core = type

    def __init__(self, core):
        self.core = core
        self.core.modulesList += [self]

    def help(self):
        pass
