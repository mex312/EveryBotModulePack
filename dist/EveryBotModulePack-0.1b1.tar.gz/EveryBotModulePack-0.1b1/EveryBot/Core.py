from EveryBot import Module
import telebot


class Core:
    modulesList = []
    bot = telebot.TeleBot("NO_TOKEN")

    def __init__(self, botToken):
        self.modulesList = [Module.Module(self)]
        self.bot.token = botToken

    def DeleteMessage(self, message: telebot.types.Message):
        self.bot.delete_message(message_id=message.id, chat_id=message.chat.id)