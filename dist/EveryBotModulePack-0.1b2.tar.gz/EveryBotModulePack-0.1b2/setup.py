from setuptools import setup

setup(
    name='EveryBotModulePack',
    version='0.1b2',
    description='Module package for EveryBot',
    packages=['EveryBot'],
    install_requires=['pyTelegramBotApi']
)